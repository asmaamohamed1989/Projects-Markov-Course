# COVID-19-Classification-2020
COVID-19 Classification 2020
### This project was made in 2020, so know you can find more data than that i had used.
## Results :
![image](https://user-images.githubusercontent.com/37241010/155917199-ff48404c-9aba-4688-8693-2d7df66966c5.png)

# Analysis-for-COVID19-cases-at-Spain
Analysis for COVID19 cases at Spain on Maps using Folium

![image](https://user-images.githubusercontent.com/37241010/155923646-450061cf-1049-4861-9678-b3d03789be46.png)


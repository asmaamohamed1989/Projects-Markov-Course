# Finding_Donors_Charity
Supervised Learning - Ensemble Techniques

Dataset : https://drive.google.com/file/d/1RWGcYnWScrS73RebFtN2thEZlHaGUvcc/view?usp=sharing

# Interactive-Maps-Clustering-San-Francisco-Police-Department-Incidents

#### Interactive Maps Clustering San Francisco Police Department Incidents using Folium Maps Lib


![image](https://user-images.githubusercontent.com/37241010/155918574-e98936fb-57aa-46fe-8dfa-b0ca6a4285c1.png)


### Dataset
https://data.sfgov.org/Public-Safety/Police-Department-Incident-Reports-2018-to-Present/wg3w-h783
